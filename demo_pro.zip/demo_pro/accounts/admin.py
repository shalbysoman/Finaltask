from django.contrib import admin

# Register your models here.

#from .models import Registration


#class RegisterAdmin(admin.ModelAdmin):
    #list_display = ('id', 'username', 'first_name', 'last_name', 'email', 'password', 'cpassword')
   # list_display_links = ('id', 'username')


#Sadmin.site.register(Registration, RegisterAdmin)

